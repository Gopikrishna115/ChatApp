﻿using ChatApplication.Hubs.Service_Contract;
using Microsoft.AspNetCore.SignalR;
using System.Threading.Tasks;

namespace ChatAppBackend.Hubs
{
    public class ChatHub : Hub
    {
        
    }

}
