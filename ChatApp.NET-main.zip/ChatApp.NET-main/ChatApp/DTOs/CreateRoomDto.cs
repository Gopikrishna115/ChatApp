namespace ChatApp.DTOs;

public class CreateRoomDto
{
    public string RoomName { get; set; }
    public string TopicName { get; set; }
    public string Description { get; set; }
}