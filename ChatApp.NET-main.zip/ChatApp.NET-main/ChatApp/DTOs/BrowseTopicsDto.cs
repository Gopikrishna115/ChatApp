namespace ChatApp.DTOs;

public class BrowseTopicsDto
{
    public string TopicName { get; set; }
    public int MessagesNo { get; set; }
}