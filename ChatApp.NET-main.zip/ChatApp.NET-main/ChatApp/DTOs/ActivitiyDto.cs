namespace ChatApp.DTOs;

public class ActivitiyDto
{
    public string UserName { get; set; }
    public string RoomName { get; set; }
    public string Created { get; set; }
    public string Message { get; set; }
}