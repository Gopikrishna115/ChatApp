using Microsoft.AspNetCore.Identity;

namespace ChatApp.Entities;

public class AppRole : IdentityRole<int>
{
}