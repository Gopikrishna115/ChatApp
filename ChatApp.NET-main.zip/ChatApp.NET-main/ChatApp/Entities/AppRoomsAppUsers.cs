// namespace ChatApp.Entities;
//
// public class AppRoomsAppUsers
// {
//     public int AppRoomsId { get; set; }
//     public AppRooms AppRooms { get; set; }
//     public int ParticipantsId { get; set; }
//     public AppUsers Participants { get; set; }
//
// }