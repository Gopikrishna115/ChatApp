export const environment = {
  production: true,
  apiUrl: "api/",
  imageUrl: "api/image/",
  hubUrl: "hubs/"
};
