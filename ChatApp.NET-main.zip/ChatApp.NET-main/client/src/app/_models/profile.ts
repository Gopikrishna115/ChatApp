export interface Profile{
  userName: string;
  avatarUrl: string;
  bio: string
  created: string
  updated: string
  messages: string[]
  hostOfRooms: string[];
}
