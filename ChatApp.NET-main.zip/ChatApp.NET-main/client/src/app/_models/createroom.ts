export interface createroom{
  roomName:string,
  topicName:string,
  description:string
}
