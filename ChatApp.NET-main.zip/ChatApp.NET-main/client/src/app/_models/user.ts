export interface User {
  userName:string;
  token:string;
  avatarUrl:string;
}
