export interface Roomchat {
  roomName:string
  roomTopic:string;
  hostName:string;
  messages:Array<{}>;
}
