export interface Message {
  userCreated : string,
  messageIsInRoom: string,
  body: string,
  created: string,
  updated: string,
  avatarUrl: string,
  topicName: string
}
